import Joi from './joi';
Joi.objectId = require('joi-objectid')(Joi);

export const objectId = Joi.object().keys({
  id: Joi.objectId().label('Object ID'),
});
