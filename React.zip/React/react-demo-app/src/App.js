import React, { useState } from 'react';
import './App.scss';
import { Navbar } from './components/Navbar';
import { Counters } from './components/Counters';

function App() {
  const [counters, setCounters] = useState([
    { id: 1, value: 4 },
    { id: 2, value: 0 },
    { id: 3, value: 1 },
    { id: 4, value: 2 },
  ]);

  const handleDelete = (counterId) => {
    const updatedCounters = counters.filter(
      (counter) => counter.id !== counterId
    );
    setCounters(updatedCounters);
  };

  const handleIncrement = (counterObject) => {
    const updatedCounters = [...counters];
    const index = updatedCounters.indexOf(counterObject);
    updatedCounters[index] = { ...counterObject };
    updatedCounters[index].value++;
    setCounters(updatedCounters);
  };

  const handleReset = () => {
    const updatedCounters = [...counters];
    updatedCounters.map((c) => {
      c.value = 0;
      return c;
    });
    setCounters(updatedCounters);
  };
  return (
    <React.Fragment>
      <Navbar
        totalCounters={counters.filter((counter) => counter.value > 0).length}
      />
      <main className='container'>
        <Counters
          onReset={handleReset}
          onDelete={handleDelete}
          onIncrement={handleIncrement}
          counters={counters}
        />
      </main>
    </React.Fragment>
  );
}

export default App;
