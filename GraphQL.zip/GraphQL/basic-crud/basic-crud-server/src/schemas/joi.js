import Joi from 'joi';
import mongoose from 'mongoose';

const objectId = {
  type: 'objectId',
  base: Joi.string(),

  messages: {
    objectId: 'must be a valid Object ID',
  },
  rules: {
    objectId: {
      validate(params, value, state, options) {
        if (!mongoose.Types.ObjectId.isValid(id)) {
          return this.createError('objectId', { value }, state, options);
        }
        return value;
      },
    },
  },
};

export default Joi.extend(objectId);
