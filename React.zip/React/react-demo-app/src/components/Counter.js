import React from 'react';

export const Counter = ({ counter, children, onIncrement, onDelete }) => {
  const formatCount = (value) => {
    return value === 0 ? 'Zero' : value;
  };

  return (
    <React.Fragment>
      {children}
      <span className={getBadgeClasses(counter.value)}>
        {formatCount(counter.value)}
      </span>
      <button
        onClick={() => onIncrement(counter)}
        className='btn btn-secondary btn-sm'
      >
        Increment
      </button>
      <button
        className='btn btn-danger btn-sm m-2'
        onClick={() => onDelete(counter.id)}
      >
        Delete
      </button>
    </React.Fragment>
  );
};

function getBadgeClasses(count) {
  let classes = 'badge m-2 badge-';
  classes += count === 0 ? 'warning' : 'primary';
  return classes;
}
