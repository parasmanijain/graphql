import Joi from '@hapi/joi';
import mongoose from 'mongoose';
import { UserInputError } from 'apollo-server-express';
import { User, Chat } from '../models';
import { signUp, signIn, objectId } from '../schemas';
import * as Auth from '../auth';
import user from '../typeDefs/user';

const isObjectId = (id) => {
  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new UserInputError(`User ID is not a valid Object ID`);
  }
  return false;
};

export default {
  Query: {
    me: (root, args, { req }, info) => {
      // TODO prjection
      return User.findById(req.session.userId);
    },
    users: (root, args, { req }, info) => {
      // TODO auth projection pagination sanitization
      return User.find({});
    },
    user: async (root, args, { req }, info) => {
      // todo auth projection sanitization
      await objectId.validateAsync(args, { abortEarly: false });
      return User.findById(args.id);
    },
  },
  Mutation: {
    signUp: async (root, args, { req }, info) => {
      // todo not auth
      // validation
      await signUp.validateAsync(args, { abortEarly: false });

      const user = await User.create(args);

      req.session.userId = user.id;

      return user;
    },
    signIn: async (root, args, { req }, info) => {
      const { userId } = req.session;

      if (userId) {
        return User.findById(userId);
      }

      await signIn.validateAsync(args, { abortEarly: false });

      const user = await Auth.attemptSignIn(args.email, args.password);

      req.session.userId = user.id;

      return user;
    },
    signOut: (root, args, { req, res }, info) => {
      return Auth.signOut(req, res);
    },
  },

  User: {
    chats: async (user, args, context, info) => {
      return (await user.populate('chats').execPopulate()).chats;
    },
  },
};
