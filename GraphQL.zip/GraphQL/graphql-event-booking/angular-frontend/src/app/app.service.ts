import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AppService {
  token = new BehaviorSubject(null);
  userId = new BehaviorSubject(null);
  tokenExpiration = new BehaviorSubject(null);
  constructor() {}

  login = (token, userId, tokenExpiration) => {
    this.token.next(token);
    this.userId.next(userId);
  };

  logout = () => {
    this.token.next(null);
    this.userId.next(null);
  };
}
