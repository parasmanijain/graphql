import GuestDirective from './guest';
import AuthDirective from './auth';

export default {
  auth: AuthDirective,
  guest: GuestDirective,
};
