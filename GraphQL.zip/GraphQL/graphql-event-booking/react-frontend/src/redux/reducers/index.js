import userReducer from './userReducer';
import eventReducer from './eventReducer';
import bookingReducer from './bookingReducer';
import { combineReducers } from 'redux';

const rootReducer = combineReducers({
  userReducer,
  eventReducer,
  bookingReducer,
});

export default rootReducer;
