import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../app.service';
@Component({
  selector: 'app-main-navigation',
  templateUrl: './main-navigation.component.html',
  styleUrls: ['./main-navigation.component.scss'],
})
export class MainNavigationComponent implements OnInit {
  public token;
  constructor(private appService: AppService, private router: Router) {}

  ngOnInit(): void {
    this.appService.token.subscribe((value) => {
      this.token = value;
    });
  }

  logout(): void {
    this.appService.userId.next(null);
    this.appService.token.next(null);
    this.router.navigate(['events']);
  }
}
