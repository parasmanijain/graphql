import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppService } from '../../app.service';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.scss'],
})
export class EventListComponent implements OnInit {
  eventsData;
  authUserIdField;

  @Input('events')
  get events(): [] {
    return this.eventsData;
  }
  set events(val) {
    if (val) {
      this.eventsData = val;
    }
  }

  @Output() onViewDetails = new EventEmitter();

  constructor(private appService: AppService) {}

  ngOnInit(): void {
    this.appService.userId.subscribe((value) => {
      this.authUserIdField = value;
    });
  }

  fetchViewDetails(event): void {
    this.onViewDetails.emit(event);
  }
}
