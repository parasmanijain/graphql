const defaultState = {
  loggedIn: false,
  userId: {},
};

const userReducer = (state = defaultState, action) => {
  switch (action.type) {
    case 'SET_USER':
      return {
        loggedIn: true,
        userId: action.payload,
      };
    case 'LOG_OUT':
      return {
        loggedIn: false,
        userId: {},
      };
    default:
      return state;
  }
};

export default userReducer;
