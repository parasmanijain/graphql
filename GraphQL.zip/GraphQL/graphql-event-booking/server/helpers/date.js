exports.dateToString = (date) => new Date(date).toISOString();
