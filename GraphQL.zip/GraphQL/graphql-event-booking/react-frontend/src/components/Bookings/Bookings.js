import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Spinner } from '../Spinner/Spinner';
import { BookingList } from '../BookingList/BookingList';
import { BookingsChart } from '../BookingsChart/BookingsChart';
import { BookingsControls } from '../BookingsControls/BookingsControls';
import './Bookings.scss';
import { BookingsQuery, CancelBookingMutaion } from '../../queries/queries';
import {
  retrieveBookings,
  removeBooking,
} from '../../redux/actions/bookingActions';

export const Bookings = () => {
  useEffect(() => {
    fetchBookings();
  }, []);

  const [isLoading, setIsLoading] = useState(false);
  const [outputType, setOutputType] = useState('list');
  const bookingReducer = useSelector((state) => state.bookingReducer);
  const dispatch = useDispatch();
  const fetchBookings = () => {
    setIsLoading(true);
    const requestBody = {
      query: BookingsQuery,
    };
    dispatch(retrieveBookings(requestBody));
    setIsLoading(false);
  };

  const deleteBookingHandler = (bookingId) => {
    setIsLoading(true);
    const requestBody = {
      query: CancelBookingMutaion,
      variables: {
        id: bookingId,
      },
    };
    dispatch(removeBooking(requestBody));
    setIsLoading(false);
  };

  const changeOutputTypeHandler = (outputType) => {
    if (outputType === 'list') {
      setOutputType('list');
    } else {
      setOutputType('chart');
    }
  };

  let content = <Spinner />;
  if (!isLoading) {
    content = (
      <React.Fragment>
        <BookingsControls
          activeOutputType={outputType}
          onChange={changeOutputTypeHandler}
        />
        <div>
          {outputType === 'list' ? (
            <BookingList
              bookings={bookingReducer.bookings}
              onDelete={deleteBookingHandler}
            />
          ) : (
            <BookingsChart bookings={bookingReducer.bookings} />
          )}
        </div>
      </React.Fragment>
    );
  }
  return <React.Fragment>{content}</React.Fragment>;
};
