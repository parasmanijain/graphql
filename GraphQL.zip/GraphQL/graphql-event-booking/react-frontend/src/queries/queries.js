export const LoginQuery = `
    query Login($email:String!, $password:String!) {
        login(email:$email, password:$password) {
        userId
        token
        tokenExpiration
        }
    }`;

export const CreateUserMutation = `
    mutation CreateUser ($email:String!, $password:String!){
      createUser(userInput: { email: $email, password:$password}) {
          _id
          email
      }
    }`;

export const BookingsQuery = `
    query {
        bookings {
        _id
        createdAt
        event {
            _id
            title
            date
            price
        }                          
        }
    }`;

export const CancelBookingMutaion = `
    mutation CancelBooking($id:ID!){
      cancelBooking(bookingId:$id) {
        _id
        title                 
      }
    }`;

export const CreateEventMutation = `
    mutation CreateEvent($title:String!, $price:Float!, $date:String!, $description:String!){
      createEvent(eventInput: { title:$title, price:$price,date:$date, description:$description}) {
        _id
        title
        description
        price
        date
      }
    }`;

export const EventsQuery = `
    query {
      events {
        _id
        title
        description
        price
        date
        creator {
          _id
          email
        }
      }
    }`;

export const BookEventMutation = `
    mutation BookEvent($eventId:ID!){
      bookEvent(eventId:$eventId) {
        _id
        createdAt
        updatedAt
      }
    }`;
