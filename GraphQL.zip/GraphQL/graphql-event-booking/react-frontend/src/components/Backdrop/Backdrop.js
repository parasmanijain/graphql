import React from 'react';

import './Backdrop.scss';
export const Backdrop = (props) => {
  return <div className='backdrop'></div>;
};
