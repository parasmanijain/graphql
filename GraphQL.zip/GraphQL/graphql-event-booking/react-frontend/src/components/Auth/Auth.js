import React, { useRef, useState } from 'react';
import './Auth.scss';
import { useDispatch } from 'react-redux';
import { LoginQuery, CreateUserMutation } from '../../queries/queries';
import { login } from '../../redux/actions/userActions';

export const Auth = () => {
  const dispatch = useDispatch();
  const emailEl = useRef(null);
  const passwordEl = useRef(null);

  const [isLogin, setIsLogin] = useState(true);
  const switchModeHandler = () => {
    setIsLogin(!isLogin);
  };
  const submitHandler = (event) => {
    event.preventDefault();
    const email = emailEl.current.value;
    const password = passwordEl.current.value;
    if (email.trim().length === 0 || password.trim().length === 0) {
      return;
    }

    let requestBody = {
      query: LoginQuery,
      variables: {
        email: email,
        password: password,
      },
    };

    if (!isLogin) {
      requestBody = {
        query: CreateUserMutation,
        variables: {
          email: email,
          password: password,
        },
      };
    }
    dispatch(login(requestBody));
  };

  return (
    <form className='auth-form' onSubmit={submitHandler}>
      <div className='form-control'>
        <label htmlFor='email'>E-mail</label>
        <input type='email' id='email' ref={emailEl} />
      </div>
      <div className='form-control'>
        <label htmlFor='password'>Password</label>
        <input type='password' id='password' ref={passwordEl} />
      </div>
      <div className='form-actions'>
        <button type='submit'>Submit</button>
        <button type='button' onClick={switchModeHandler}>
          Switch to {isLogin ? 'Signup' : 'Login'}
        </button>
      </div>
    </form>
  );
};

export default Auth;
