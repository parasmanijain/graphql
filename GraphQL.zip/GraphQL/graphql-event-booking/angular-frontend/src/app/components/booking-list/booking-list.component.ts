import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrls: ['./booking-list.component.scss'],
})
export class BookingListComponent implements OnInit {
  bookingsData;
  @Input('bookings')
  get bookings(): [] {
    return this.bookingsData;
  }
  set bookings(val) {
    if (val) {
      this.bookingsData = val;
    }
  }

  @Output() onDelete = new EventEmitter();
  constructor() {}

  ngOnInit(): void {}

  deleteBooking(bookingId): void {
    this.onDelete.emit(bookingId);
  }
}
