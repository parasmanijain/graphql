import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { AppService } from '../../app.service';
import { AuthService } from './auth.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss'],
})
export class AuthComponent implements OnInit {
  authForm = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
  });

  isLogin = true;
  constructor(
    private authService: AuthService,
    private appService: AppService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.appService.token.subscribe((value) => {
      if (value) {
        this.router.navigate(['events']);
      }
    });
  }

  switchModeHandler = () => {
    this.isLogin = !this.isLogin;
    return this.isLogin;
  };

  submitHandler = (event) => {
    event.preventDefault();
    const email = this.authForm.get('email').value;
    const password = this.authForm.get('password').value;
    if (email.trim().length === 0 || password.trim().length === 0) {
      return;
    }

    let requestBody = {
      query: `
        query Login($email:String!, $password:String!) {
          login(email:$email, password:$password) {
            userId
            token
            tokenExpiration
          }
        }`,
      variables: {
        email: email,
        password: password,
      },
    };

    if (!this.isLogin) {
      requestBody = {
        query: `
          mutation CreateUser ($email:String!, $password:String!){
            createUser(userInput: { email: $email, password:$password}) {
              _id
              email
            }
          }`,
        variables: {
          email: email,
          password: password,
        },
      };
    }

    try {
      this.authService.login(requestBody).subscribe((res) => {
        if (res.login.token) {
          this.appService.token.next(res.login.token);
          this.appService.userId.next(res.login.userId);
          this.appService.tokenExpiration.next(res.login.tokenExpiration);
          this.router.navigate(['events']);
        }
      });
    } catch (err) {
      console.log(err);
    }
  };
}
