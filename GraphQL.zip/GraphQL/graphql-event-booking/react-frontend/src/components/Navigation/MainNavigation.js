import React from 'react';
import { NavLink } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import './MainNavigation.scss';
import { logUserOut } from '../../redux/actions/userActions';

export const MainNavigation = () => {
  const userReducer = useSelector((state) => state.userReducer);
  const dispatch = useDispatch();

  const logout = () => {
    dispatch(logUserOut());
  };
  return (
    <header className='main-navigation'>
      <div className='main-navigation__logo'>
        <h1>Easy Event</h1>
      </div>
      <nav className='main-navigation__items'>
        <ul>
          {' '}
          {!userReducer.loggedIn && (
            <li>
              <NavLink to='/auth'>Authenticate</NavLink>
            </li>
          )}
          <li>
            <NavLink to='/events'>Events</NavLink>
          </li>
          {userReducer.loggedIn && (
            <React.Fragment>
              <li>
                <NavLink to='/bookings'>Bookings</NavLink>
              </li>
              <li>
                <button onClick={logout}>Logout</button>
              </li>
            </React.Fragment>
          )}
        </ul>
      </nav>
    </header>
  );
};
