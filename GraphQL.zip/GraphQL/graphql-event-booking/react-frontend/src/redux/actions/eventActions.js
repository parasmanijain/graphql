import axios from 'axios';

const instance = axios.create();

instance.interceptors.request.use(
  (config) => {
    config.headers['Authorization'] = 'Bearer ' + localStorage.getItem('token');
    return config;
  },
  (error) => {
    Promise.reject(error);
  }
);

const fetchEvents = (payload) => ({ type: 'FETCH_EVENTS', payload });

const createEvent = (payload) => ({ type: 'CREATE_EVENT', payload });

export const createNewEvent = (requestBody) => async (dispatch) => {
  const options = {
    url: 'http://localhost:4000/graphql',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: requestBody,
  };
  try {
    const res = await instance(options);
    if (res.status !== 200 && res.status !== 201) {
      throw new Error('Failed!');
    }
    dispatch(createEvent(res.data.data.createEvent));
  } catch (err) {
    console.log(err);
  }
};

export const retrieveEvents = (requestBody) => async (dispatch) => {
  const options = {
    url: 'http://localhost:4000/graphql',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: requestBody,
  };
  try {
    const res = await instance(options);
    if (res.status !== 200 && res.status !== 201) {
      throw new Error('Failed!');
    }
    dispatch(fetchEvents(res.data.data.events));
  } catch (err) {
    console.log(err);
  }
};
