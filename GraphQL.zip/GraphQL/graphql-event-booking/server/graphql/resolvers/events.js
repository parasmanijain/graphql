const Event = require('../../models/event');
const User = require('../../models/user');
const { transformEvent } = require('./merge');

module.exports = {
  events: async () => {
    try {
      const foundEvents = await Event.find();
      return foundEvents.map((event) => {
        return transformEvent(event);
      });
    } catch (e) {
      throw e;
    }
  },
  createEvent: async (args, req) => {
    try {
      if (!req.isAuth) {
        throw new Error('UnAuthenticated');
      }
      const { title, description, price, date } = args.eventInput;
      const event = new Event({
        title,
        description,
        price: +price,
        date,
        creator: req.userId,
      });
      const creator = await User.findById(req.userId);
      if (!creator) {
        throw new Error('Creator does not exist!');
      }
      let createdEvent;
      const result = await event.save();
      createdEvent = transformEvent(result);

      creator.createdEvents.push(event);
      await creator.save();
      return createdEvent;
    } catch (err) {
      throw err;
    }
  },
};
