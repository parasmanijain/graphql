import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { AppService } from '../../app.service';
import { EventsService } from './events.service';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss'],
})
export class EventsComponent implements OnInit, OnDestroy {
  creating = false;
  token;
  userId;
  events = [];
  isLoading = false;
  selectedEvent = null;
  isActive = true;
  createEventForm = new FormGroup({
    title: new FormControl(''),
    price: new FormControl(''),
    date: new FormControl(''),
    description: new FormControl(''),
  });

  constructor(
    private appService: AppService,
    private eventsService: EventsService
  ) {}

  ngOnInit(): void {
    this.appService.token.subscribe((value) => {
      this.token = value;
    });
    this.fetchEvents();
  }

  startCreateEventHandler = () => {
    this.creating = true;
  };

  modalConfirmHandler = () => {
    const title = this.createEventForm.get('title').value;
    const price = +this.createEventForm.get('price').value;
    const date = this.createEventForm.get('date').value;
    const description = this.createEventForm.get('description').value;

    if (
      title.trim().length === 0 ||
      price <= 0 ||
      date.trim().length === 0 ||
      description.trim().length === 0
    ) {
      return;
    }
    const event = { title, price, date, description };
    this.creating = false;

    const requestBody = {
      query: `
        mutation CreateEvent($title:String!, $price:Float!, $date:String!, $description:String!){
          createEvent(eventInput: { title:$title, price:$price,date:$date, description:$description}) {
            _id
            title
            description
            price
            date
          }
        }`,
      variables: {
        title: title,
        price: price,
        description: description,
        date: date,
      },
    };
    try {
      this.eventsService.createEvent(requestBody).subscribe((res) => {
        if (res) {
          this.fetchEvents();
        }
      });
    } catch (err) {
      console.log(err);
    }
  };

  modalCancelHandler = () => {
    this.creating = false;
    this.selectedEvent = null;
  };

  showDetailHandler = (eventId) => {
    this.selectedEvent = this.events.find((e) => e._id === eventId);
  };

  fetchEvents = () => {
    this.isLoading = true;
    const requestBody = {
      query: `
                  query {
                      events {
                          _id
                          title
                          description
                          price
                          date
                          creator {
                              _id
                              email
                          }
                      }
                  }`,
    };
    try {
      this.eventsService.getEvents(requestBody).subscribe((res) => {
        if (this.isActive) {
          if (res) {
            this.events = res.events;
          }
          this.isLoading = false;
        }
      });
    } catch (err) {
      console.log(err);
      if (this.isActive) {
        this.isLoading = false;
      }
    }
  };

  bookEventHandler = () => {
    if (!this.token) {
      this.selectedEvent = null;
      return;
    }
    this.isLoading = true;
    const requestBody = {
      query: `
        mutation BookEvent($eventId:ID!){
          bookEvent(eventId:$eventId) {
            _id
            createdAt
            updatedAt
          }
        }`,
      variables: {
        eventId: this.selectedEvent._id,
      },
    };
    try {
      this.eventsService.bookEvent(requestBody).subscribe((res) => {
        console.log(res);
        this.isLoading = false;
        this.selectedEvent = null;
      });
    } catch (err) {
      console.log(err);
      this.isLoading = false;
      this.selectedEvent = null;
    }
  };

  ngOnDestroy(): void {
    this.isActive = false;
  }
}
