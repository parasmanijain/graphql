import axios from 'axios';

const instance = axios.create();

instance.interceptors.request.use(
  (config) => {
    config.headers['Authorization'] = 'Bearer ' + localStorage.getItem('token');
    return config;
  },
  (error) => {
    Promise.reject(error);
  }
);

const fetchBookings = (payload) => ({ type: 'FETCH_BOOKINGS', payload });

const createBooking = (payload) => ({ type: 'CREATE_BOOKING', payload });

const cancelBooking = (payload) => ({ type: 'CANCEL_BOOKING', payload });

export const createNewBooking = (requestBody) => async (dispatch) => {
  const options = {
    url: 'http://localhost:4000/graphql',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: requestBody,
  };
  try {
    const res = await instance(options);
    if (res.status !== 200 && res.status !== 201) {
      throw new Error('Failed!');
    }
    dispatch(createBooking(res.data.data.createEvent));
  } catch (err) {
    console.log(err);
  }
};

export const retrieveBookings = (requestBody) => async (dispatch) => {
  const options = {
    url: 'http://localhost:4000/graphql',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: requestBody,
  };
  try {
    const res = await instance(options);
    if (res.status !== 200 && res.status !== 201) {
      throw new Error('Failed!');
    }
    dispatch(fetchBookings(res.data.data.bookings));
  } catch (err) {
    console.log(err);
  }
};

export const removeBooking = (requestBody) => async (dispatch) => {
  const options = {
    url: 'http://localhost:4000/graphql',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: requestBody,
  };
  try {
    const res = await instance(options);
    if (res.status !== 200 && res.status !== 201) {
      throw new Error('Failed!');
    }
    dispatch(cancelBooking(requestBody.variables.id));
  } catch (err) {
    console.log(err);
  }
};
