import axios from 'axios';

const instance = axios.create();

instance.interceptors.request.use(
  (config) => {
    const apiService = ApiService.getService();
    const token = apiService.getToken();
    if (token) {
      config.headers['Authorization'] = 'Bearer ' + token;
    }
    return config;
  },
  (error) => {
    Promise.reject(error);
  }
);

const ApiService = (function () {
  var _service;

  function _getService() {
    if (!_service) {
      _service = this;
      return _service;
    }
    return _service;
  }
  async function _callAPI(requestBody) {
    const options = {
      url: 'http://localhost:4000/graphql',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: requestBody,
    };
    try {
      const res = await instance(options);
      if (res.status !== 200 && res.status !== 201) {
        throw new Error('Failed!');
      }
      return res.data;
    } catch (err) {
      debugger;
      console.log(err);
    }
  }

  return {
    getService: _getService,
    callAPI: _callAPI,
  };
})();
export default ApiService;
