import React from 'react';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';
import './App.scss';
import { useSelector } from 'react-redux';
import { Auth } from './components/Auth/Auth';
import { Events } from './components/Events/Events';
import { Bookings } from './components/Bookings/Bookings';
import { MainNavigation } from './components/Navigation/MainNavigation';

function App() {
  const userReducer = useSelector((state) => state.userReducer);
  return (
    <BrowserRouter>
      <MainNavigation />
      <main className='main-content'>
        <Switch>
          {userReducer.loggedIn && <Redirect from='/' to='/events' exact />}
          {userReducer.loggedIn && <Redirect from='/auth' to='/events' exact />}
          {!userReducer.loggedIn && <Route path='/auth' component={Auth} />}
          <Route path='/events' component={Events} />
          {userReducer.loggedIn && (
            <Route path='/bookings' component={Bookings} />
          )}
          {!userReducer.loggedIn && <Redirect to='/auth' exact />}
        </Switch>
      </main>
    </BrowserRouter>
  );
}

export default App;
