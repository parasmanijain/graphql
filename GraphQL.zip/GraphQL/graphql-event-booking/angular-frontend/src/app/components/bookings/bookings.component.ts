import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';
import { BookingsService } from './bookings.service';
@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.scss'],
})
export class BookingsComponent implements OnInit {
  token;
  userId;
  bookingsData = [];
  isLoading = false;
  constructor(
    private appService: AppService,
    private bookingsService: BookingsService
  ) {}

  ngOnInit(): void {
    this.appService.token.subscribe((value) => {
      this.token = value;
    });
    this.appService.userId.subscribe((value) => {
      this.userId = value;
    });
    this.fetchBookings();
  }

  fetchBookings = () => {
    this.isLoading = true;
    const requestBody = {
      query: `
        query {
          bookings {
              _id
              createdAt
              event {
                _id
                title
                date
              }
          }
      }`,
    };
    try {
      this.bookingsService.getBookings(requestBody).subscribe((res) => {
        if (res) {
          this.bookingsData = res.bookings;
        }
        this.isLoading = false;
      });
    } catch (err) {
      console.log(err);
      this.isLoading = false;
    }
  };

  deleteBookingHandler = (bookingId) => {
    this.isLoading = true;
    const requestBody = {
      query: `
        mutation CancelBooking($id:ID!){
          cancelBooking(bookingId:$id) {
            _id
            title
          }
        }`,
      variables: {
        id: bookingId,
      },
    };
    try {
      this.bookingsService.cancelBooking(requestBody).subscribe((res) => {
        if (res) {
          const updatedBookings = this.bookingsData.filter((booking) => {
            return booking._id !== bookingId;
          });
          this.bookingsData = updatedBookings;
          this.isLoading = false;
        }
      });
    } catch (err) {
      console.log(err);
      this.isLoading = false;
    }
  };
}
