import axios from 'axios';

const instance = axios.create();

instance.interceptors.request.use(
  (config) => {
    config.headers['Authorization'] = 'Bearer ' + localStorage.getItem('token');
    return config;
  },
  (error) => {
    Promise.reject(error);
  }
);

const setUser = (payload) => ({ type: 'SET_USER', payload });

const logOut = () => ({ type: 'LOG_OUT' });

export const login = (requestBody) => async (dispatch) => {
  const options = {
    url: 'http://localhost:4000/graphql',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: requestBody,
  };
  try {
    const res = await instance(options);
    if (res.status !== 200 && res.status !== 201) {
      throw new Error('Failed!');
    }
    localStorage.setItem('token', res.data.data.login.token);
    dispatch(setUser(res.data.data.login.userId));
  } catch (err) {
    console.log(err);
  }
};

export const signUserUp = (requestBody) => async (dispatch) => {
  const options = {
    url: 'http://localhost:4000/graphql',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: requestBody,
  };
  try {
    const res = await instance(options);
    if (res.status !== 200 && res.status !== 201) {
      throw new Error('Failed!');
    }
    localStorage.setItem('token', res.data.data.login.token);
    dispatch(setUser(res.data.data.login.userId));
  } catch (err) {
    console.log(err);
  }
};

export const logUserOut = () => (dispatch) => {
  try {
    debugger;
    localStorage.clear();
    dispatch(logOut());
  } catch (err) {
    console.log(err);
  }
};
