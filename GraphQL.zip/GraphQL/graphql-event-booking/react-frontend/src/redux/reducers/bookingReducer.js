const defaultState = {
  bookings: [],
};

const bookingReducer = (state = defaultState, action) => {
  switch (action.type) {
    case 'FETCH_BOOKINGS':
      return {
        bookings: [...action.payload],
      };
    case 'BOOK_EVENT':
      return {
        bookings: [...action.payload],
      };
    case 'CANCEL_BOOKING':
      let newstate = [...state.bookings];
      newstate = newstate.filter((booking) => booking._id !== action.payload);
      return {
        bookings: newstate,
      };
    default:
      return state;
  }
};

export default bookingReducer;
