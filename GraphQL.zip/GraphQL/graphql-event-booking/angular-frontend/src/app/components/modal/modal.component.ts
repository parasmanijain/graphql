import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
})
export class ModalComponent implements OnInit {
  titleField;
  childrenField;
  confirmTextField;
  canCancelFlag;
  canConfirmFlag;

  @Input('title')
  get title() {
    return this.titleField;
  }
  set title(val) {
    if (val) {
      this.titleField = val;
    }
  }

  @Input('children')
  get children() {
    return this.childrenField;
  }
  set children(val) {
    if (val) {
      this.childrenField = val;
    }
  }

  @Input('canCancel')
  get canCancel() {
    return this.canCancelFlag;
  }
  set canCancel(val) {
    if (val) {
      this.canCancelFlag = val;
    }
  }

  @Input('canConfirm')
  get canConfirm() {
    return this.canConfirmFlag;
  }
  set canConfirm(val) {
    if (val) {
      this.canConfirmFlag = val;
    }
  }

  @Input('confirmText')
  get confirmText() {
    return this.confirmTextField;
  }
  set confirmText(val) {
    if (val) {
      this.confirmTextField = val;
    }
  }

  @Output() cancel = new EventEmitter();
  @Output() confirm = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}

  onCancel(): void {
    this.cancel.emit();
  }

  onConfirm(): void {
    this.confirm.emit();
  }
}
