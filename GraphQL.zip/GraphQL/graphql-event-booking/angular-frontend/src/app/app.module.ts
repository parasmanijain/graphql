import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { TokenInterceptorService } from './interceptors/token-interceptor.service';
import { AuthComponent } from './components/auth/auth.component';
import { AppComponent } from './app.component';
import { EventsComponent } from './components/events/events.component';
import { BookingsComponent } from './components/bookings/bookings.component';
import { MainNavigationComponent } from './components/main-navigation/main-navigation.component';
import { AppService } from './app.service';
import { AuthGuard } from './auth.guard';
import { AuthService } from './components/auth/auth.service';
import { BackdropComponent } from './components/backdrop/backdrop.component';
import { ModalComponent } from './components/modal/modal.component';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { EventListComponent } from './components/event-list/event-list.component';
import { EventItemComponent } from './components/event-item/event-item.component';
import { DateFormatPipe } from './pipes/date-format.pipe';
import { BookingListComponent } from './components/booking-list/booking-list.component';

@NgModule({
  declarations: [
    AppComponent,
    AuthComponent,
    EventsComponent,
    BookingsComponent,
    MainNavigationComponent,
    BackdropComponent,
    ModalComponent,
    SpinnerComponent,
    EventListComponent,
    EventItemComponent,
    DateFormatPipe,
    BookingListComponent,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true,
    },
    AppService,
    AuthGuard,
    AuthService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
