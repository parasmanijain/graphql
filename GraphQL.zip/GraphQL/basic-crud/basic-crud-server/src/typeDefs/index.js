import root from './root';
import chat from './chat';
import message from './message';
import user from './user';

export default [root, user, chat, message];
