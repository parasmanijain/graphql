import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppService } from '../../app.service';

@Component({
  selector: 'app-event-item',
  templateUrl: './event-item.component.html',
  styleUrls: ['./event-item.component.scss'],
})
export class EventItemComponent implements OnInit {
  eventIdField;
  titleField;
  priceField;
  dateField;
  userIdField;
  creatorIdField;

  @Output() onDetail = new EventEmitter();

  @Input('eventId')
  get eventId(): string {
    return this.eventIdField;
  }
  set eventId(val) {
    if (val) {
      this.eventIdField = val;
    }
  }

  @Input('title')
  get title(): string {
    return this.titleField;
  }
  set title(val) {
    if (val) {
      this.titleField = val;
    }
  }

  @Input('price')
  get price(): number {
    return this.priceField;
  }
  set price(val) {
    if (val) {
      this.priceField = val;
    }
  }

  @Input('date')
  get date(): string {
    return this.dateField;
  }
  set date(val) {
    if (val) {
      this.dateField = val;
    }
  }

  @Input('creatorId')
  get creatorId(): string {
    return this.creatorIdField;
  }
  set creatorId(val) {
    if (val) {
      this.creatorIdField = val;
    }
  }
  constructor(private appService: AppService) {}

  ngOnInit(): void {
    this.appService.userId.subscribe((value) => {
      this.userIdField = value;
    });
  }

  fetchDetails(): void {
    this.onDetail.emit(this.eventIdField);
  }
}
